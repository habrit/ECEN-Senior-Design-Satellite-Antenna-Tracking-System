import React, { useState, useRef, useEffect } from "react";

const DropdownMenu = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);

  const toggleMenu = () => setIsOpen(!isOpen);

  const handleClickOutside = (event) => {
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div ref={menuRef} className="dropdown-menu">
      <button className="dropdown-menu__button" onClick={toggleMenu}>
        Menu {isOpen ? "✕" : "☰"}
      </button>
      {isOpen && <div className="dropdown-menu__content">{children}</div>}
    </div>
  );
};

export default DropdownMenu;
