import React from "react";
import {
  Popover,
  List,
  ListItem,
  ListItemText,
  Switch
} from "@material-ui/core";

function MapSettings({
  anchorEl,
  setAnchorEl,
  showGrid,
  setShowGrid,
  showDayNight,
  setShowDayNight,
  showGroundTrack,
  setShowGroundTrack
}) {
  const open = Boolean(anchorEl);

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleShowGridChange = (event) => {
    setShowGrid(event.target.checked);
  };

  const handleShowDayNightChange = (event) => {
    setShowDayNight(event.target.checked);
  };

  const handleShowGroundTrackChange = (event) => {
    setShowGroundTrack(event.target.checked);
  };

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: "top",
        horizontal: "left" // Change to "left"
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "left" // Change to "left"
      }}
      style={{ marginLeft: "-50px" }} // Add this style to move the popover more to the left
    >
      <List>
        <ListItem>
          <ListItemText primary="Grid" />
          <Switch
            checked={showGrid}
            onChange={handleShowGridChange}
            color="primary"
          />
        </ListItem>
        <ListItem>
          <ListItemText primary="Day/Night" />
          <Switch
            checked={showDayNight}
            onChange={handleShowDayNightChange}
            color="primary"
          />
        </ListItem>
        <ListItem>
          <ListItemText primary="Ground Track" />
          <Switch
            checked={showGroundTrack}
            onChange={handleShowGroundTrackChange}
            color="primary"
          />
        </ListItem>
      </List>
    </Popover>
  );
}

export default MapSettings;
