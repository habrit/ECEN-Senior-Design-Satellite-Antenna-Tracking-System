import {
  ecfToLookAngles,
  propagate,
  gstime,
  twoline2satrec,
  eciToEcf,
  eciToGeodetic,
  degreesLong,
  degreesLat
} from "satellite.js";

export async function getSatellite(satelliteName) {
  //Retrieve orbital data from Celestrak
  const OMM = await fetchOrbitalData(satelliteName, "JSON");
  const TLE = await fetchOrbitalData(satelliteName, "TLE");
  const satRec = getSatRec(TLE);
  const positionGd = getPositionGd(satRec);

  //Construct satellite object
  const satellite = {
    Name: satelliteName,
    Time: getTimeUTC(positionGd),
    Longitude: degreesLong(positionGd.longitude),
    Latitude: degreesLat(positionGd.latitude),
    Altitude: positionGd.height,
    SatRec: satRec,
    Omm: OMM
  };

  return satellite;
}

export async function getRotator(IP) {
  if (isValid(IP)) {
    const connectResponse = await fetchJson(IP, "Connect");
    if (connectResponse !== undefined) {
      // Construct Rotator
      const rotator = {
        Name: connectResponse.NAME,
        IP: connectResponse.IP,
        Call_Sign: connectResponse.CALL_SIGN,
        Model: connectResponse.MODEL,
        Time: getLocalTime(connectResponse.LONGITUDE),
        ObserverGd: {
          longitude: connectResponse.LONGITUDE,
          latitude: connectResponse.LATITUDE,
          height: connectResponse.HEIGHT
        },
        Look_Angles: null,
        isTracking: false
      };

      return rotator;
    } else {
      return "Request has Timed Out. Please check IP address.";
    }
  } else {
    return "Invalid IP address. Please enter a valid IP address.";
  }
}

function fetchOrbitalData(satelliteName, format) {
  // Construct URL
  const url = `https://www.celestrak.com/NORAD/elements/gp.php?NAME=${satelliteName}&FORMAT=${format}`;
  // Request document from URL
  return fetch(url)
    .then((response) => response.text())
    .then((data) => {
      if (format === "TLE") {
        // send TLE
        return data;
      } else {
        // parse JSON into Object
        return JSON.parse(data)[0];
      }
    })
    .catch((error) => {
      console.error(error);
    });
}

export async function fetchJson(IP, requestType, payload) {
  try {
    if (isValid(IP)) {
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Request timed out")), 10000)
      );
      var url = "";

      if (Boolean(payload)) {
        url = `https://${IP}/${requestType}/r/${payload}`;
      } else {
        url = `https://${IP}/${requestType}/r`;
      }

      const response = await Promise.race([fetch(url), timeoutPromise]);

      const data = await response.json();
      return data;
    } else {
      throw new Error("Invalid IP Address");
    }
  } catch (error) {
    console.error(error);
  }
}

export function getPositionGd(satRec) {
  const gmst = gstime(new Date());
  const positionEci = propagate(satRec, new Date()).position;

  return eciToGeodetic(positionEci, gmst);
}

function getSatRec(tle) {
  var line1 = tle.split("\n")[1];
  var line2 = tle.split("\n")[2];
  const satrec = twoline2satrec(line1, line2);

  return satrec;
}

export function getLookAngles(observerGd, satRec) {
  //note: not test, observerGd may need to be converted to radians

  const gmst = gstime(new Date());
  const positionEci = propagate(satRec, new Date()).position;
  const positionEcf = eciToEcf(positionEci, gmst);
  const lookAngles = ecfToLookAngles(observerGd, positionEcf);

  return {
    azimuth: lookAngles.azimuth,
    elevation: lookAngles.elevation,
    rangeSat: lookAngles.rangeSat
  };
}

function isValid(IP) {
  const regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return regex.test(IP);
}

function getLocalTime(Longitude) {
  const date = new Date(); // get current date and time
  const offset = Longitude / 15; // calculate time difference from GMT
  const localTime = date.setHours(date.getHours() + offset); // adjust date and time based on offset
  return new Date(localTime); // return the local time as a Date object
}

function getTimeUTC(positionGd) {
  const gmst = gstime(new Date());
  const now = new Date();
  const lmst = gmst + degreesLong(positionGd.longitude) / 15;

  return new Date(now.getTime() + (lmst - gmst) * 3600 * 1000);
}
