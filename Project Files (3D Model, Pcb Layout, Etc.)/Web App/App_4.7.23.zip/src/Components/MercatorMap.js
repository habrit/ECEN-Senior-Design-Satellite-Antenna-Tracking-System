import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import { loadModules } from "esri-loader";
import { Button } from "@material-ui/core";
import { Build as BuildIcon } from "@material-ui/icons";
import MapSettings from "./MapSettings";
import "./Map.css";

function MercatorMap({ Satellite }) {
  const MapElement = useRef(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const [showGrid, setShowGrid] = useState(false);
  const [showDayNight, setShowDayNight] = useState(false);
  const [showGroundTrack, setShowGroundTrack] = useState(false);

  useEffect(() => {
    let view;

    loadModules(["esri/views/MapView", "esri/Map"], {
      css: true
    }).then(([MapView, Map]) => {
      const map = new Map({
        basemap: "hybrid"
      });

      view = new MapView({
        container: MapElement.current,
        map: map,
        zoom: 4,
        constraints: {
          minZoom: 4
        }
      });

      const handleToggleMapSettings = (event) => {
        setAnchorEl(event.currentTarget);
      };

      var node = document.createElement("div");
      view.ui.add(node, "top-right");
      createRoot(node).render(
        <Button
          onClick={handleToggleMapSettings}
          style={{ backgroundColor: "white", width: "34px", minWidth: "0px" }}
        >
          <BuildIcon style={{ width: "100%" }} />
        </Button>
      );

      view.ui.move("zoom", "top-right");
    });

    return () => {
      if (view) {
        view.destroy();
      }
    };
  }, []);

  return (
    <div
      style={{
        height: "calc(100% - 64px)",
        width: "100%",
        position: "absolute",
        top: 64,
        left: 0
      }}
      ref={MapElement}
    >
      <div style={{ position: "absolute", right: "100px" }}>
        <MapSettings
          anchorEl={anchorEl}
          setAnchorEl={setAnchorEl}
          showGrid={showGrid}
          setShowGrid={setShowGrid}
          showDayNight={showDayNight}
          setShowDayNight={setShowDayNight}
          showGroundTrack={showGroundTrack}
          setShowGroundTrack={setShowGroundTrack}
        />
      </div>
    </div>
  );
}

export default MercatorMap;
